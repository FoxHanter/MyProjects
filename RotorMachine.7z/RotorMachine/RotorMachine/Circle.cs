﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RotorMachine
{
    class Circle
    {
        private int[] InputLamps = {0,1,2,3,4,5};
        private int[] OutputLamps = {4,1,3,2,0,5};

        public void Move()
        {
            int item = InputLamps[0];
            for (int i = 1; i < 6; i++)
            {
                var it = InputLamps[i];
                InputLamps[i] = item;
                item = it;
            }
            InputLamps[0] = item;

             item = OutputLamps[0];
            for (int i = 5; i>=0; i--)
            {
                var it = OutputLamps[i];
                OutputLamps[i] = item;
                item = it;
            }
            OutputLamps[5] = item;
        }

        public int GetLetter(int index)
        {
            var color = InputLamps[index];
            var newIndex = -1;

            for (int i = 0; i < 6; i++)
                if (OutputLamps[i] == color)
                {
                    newIndex = i;
                    break;
                }

            return Reflection(newIndex);
        }

        private int Reflection(int index)
        {
            switch(index)
            {
                case 0:
                    return OutputLamps[4];
                case 1:
                    return OutputLamps[5];
                case 2:
                    return OutputLamps[0]; 
                case 3:
                    return OutputLamps[4];
                case 4:
                    return OutputLamps[0];
                case 5:
                    return OutputLamps[1];
            }

            return -1;
        }
    }
}

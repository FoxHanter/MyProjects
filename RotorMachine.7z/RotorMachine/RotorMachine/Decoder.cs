﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RotorMachine
{
    class Decoder
    {
        private List<char> _letters = new List<char>(){'O','P', 'R', 'S', 'T', 'Y'};
        private Circle _circle;
        public Decoder(string text)
        {
            for (int j = 0; j < 5; j++)
            {
                _circle = new Circle();
                StringBuilder sb = new StringBuilder();

                for (int i = 0; i < text.Length; i++)
                {
                    sb.Append(_letters[(_circle.GetLetter(_letters.IndexOf(text[i])) + i+j) % 5]);
                    _circle.Move();
                }

                Console.WriteLine(sb);

            }
        }
    }
}

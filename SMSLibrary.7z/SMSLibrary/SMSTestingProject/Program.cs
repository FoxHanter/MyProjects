﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SMSLibrary;
namespace SMSTestingProject
{
    class Program
    {
        static void Main(string[] args)
        {
            /* TimeGenerator generator = new TimeGenerator(5);

             foreach (var item in generator.Generate(5))
             {
                 Console.WriteLine(item);
             }*/

            SMS mS = new SMS(5);
            mS.Work(15);
        }
    }
}

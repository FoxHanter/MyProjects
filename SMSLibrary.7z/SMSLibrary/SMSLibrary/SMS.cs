﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMSLibrary
{
   public  class SMS
    {
        public List<Channel> Channels { get; set; }

        public SMS(int count)
        {
            Channels = new List<Channel>();

            for (int i = 0; i < count; i++)
            {
                Channels.Add(new Channel(1));
            }
        }

        public void Work(int count)
        {
            TimeGenerator generator = new TimeGenerator(5);
            var time = generator.Generate(count);
            List<int> fall = new List<int>();
            for (int i = 0; i < count; i++)
            {
                bool find = false;
                for (int j = 0; j < Channels.Count(); j++)
                {                    
                    if (Channels[j].Free(time[i]))
                    {
                        Channels[j].AddRequests(i, time[i]);
                        find = true;
                        break;
                    }
                }
                if (!find)
                    fall.Add(i);
            }

            Console.WriteLine("не приняли:");
            foreach (var item in fall)
            {
                Console.Write($"{item} ");
            }
            Console.WriteLine();
            for (int i = 0; i < Channels.Count(); i++)
            {
                Console.WriteLine($"Канал {i} принял:");
                foreach (var item in Channels[i].SuccessRequests)
                {
                    Console.Write($"{item} ");
                }

                Console.WriteLine();
            }
        }
    }
}

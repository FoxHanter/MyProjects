﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMSLibrary
{
    public class Channel
    {
        public List<int> SuccessRequests { get; set; }
        public double ReleaseTime { get; set; }
        public double WorkTime { get; set; }

        public Channel(double workTime)
        {
            ReleaseTime = 0;
            SuccessRequests = new List<int>();
            WorkTime = workTime;
        }

        public bool Free(double time)
        {
            if (time>ReleaseTime)
                return true;

            return false;
        }

        public void AddRequests(int number,double time)
        {
            SuccessRequests.Add(number);
            ReleaseTime = time + WorkTime;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMSLibrary
{
    public class TimeGenerator
    {
        public int Lambda { get; set; }

        public TimeGenerator(int lambda)
        {
            Lambda = lambda;
        }

        public List<double> Generate(int count)
        {
            var times = new List<double>();
            Random random = new Random();
            double lastTime = 0;

            for (int i = 0; i < count; i++)
            {
                double r = (double)random.Next(1, 10)/10;
                 double time = -Math.Log(r)/Lambda+lastTime;
                lastTime = time;
                times.Add(lastTime);
            }

            return times;
        }
    }
}
